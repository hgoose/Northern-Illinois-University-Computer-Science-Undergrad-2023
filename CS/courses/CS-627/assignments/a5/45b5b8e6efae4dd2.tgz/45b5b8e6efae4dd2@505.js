import define1 from "./4f3615c7e4d21e01@257.js";

function _1(htl){return(
htl.html`<div id="info">
  <div class="left">
    <h1 class="left-text">Nate Warner</h1>
    <h2 class="left-text">z2004109</h2>
  </div>
  <div class="right">
    <h2 class="right-text">Data visualization (CSCI 627/490 Section N9)</h2>
    <h2 class="right-text">Assignment 5</h2>
  </div>
</div>`
)}

function _2(htl){return(
htl.html`<style>
  * { margin: 0; }

  #info { display: flex }

  .left {
    margin: 1%;
    display: flex;
    width: 70%;
    flex-direction: column;
  }
  .left .left-text { color: blue; }

  .right {
    margin: 1%;
    display: flex;
    flex-direction: column;
    width: 30%;
    border: 3px solid green;
  }
  .right .right-text {
    text-align: right;
    margin-right: 10px;
    color: blue;
    font-style: italic;
    font-weight: normal;
  }
</style>`
)}

function _states(d3){return(
d3.json("https://gist.githubusercontent.com/dakoop/771a0c3ca9c75c7c7fdc33b12b578724/raw/025cbd5dd1a263659bfb62594d0fe0463e008283/us-states.geosjson")
)}

async function _flights(d3){return(
(await d3.json("https://raw.githubusercontent.com/dakoop/niu-cs627-2026sp/refs/heads/main/a5/flights-2026-03-01.json")).map(d => ({...d, departure_dt: new Date(d.departure_dt + "Z"), arrival_dt: new Date(d.arrival_dt + "Z")}))
)}

function _airports(d3){return(
d3.json("https://raw.githubusercontent.com/dakoop/niu-cs627-2026sp/refs/heads/main/a5/airports.geojson")
)}

function _airportLookup(airports){return(
new Map(airports.features.map(d => [d.properties.loc_id, d.properties]))
)}

function _airportCounts(d3,flights){return(
d3.rollup(flights.flatMap(d => [d.origin_apt, d.dest_apt]), v => v.length, d => d)
)}

function _LARGE_THRESHOLD(){return(
100
)}

function _largeAirportCodes(airportCounts,LARGE_THRESHOLD){return(
new Set([...airportCounts].filter(([apt, count]) => count > LARGE_THRESHOLD).map(([apt, count]) => apt))
)}

function _largeAirportCodesSorted(largeAirportCodes){return(
[...largeAirportCodes].sort()
)}

function _largeAirports(airports,largeAirportCodes){return(
airports.features.filter(d => largeAirportCodes.has(d.properties.loc_id))
)}

function _flightCounts(d3,flights,largeAirportCodes)
{
  const flightsRollup = d3.flatRollup(
    flights.filter(d => largeAirportCodes.has(d.origin_apt) && largeAirportCodes.has(d.dest_apt)),
    v => v.length,
    d => d.origin_apt,
    d => d.dest_apt
  );
  const flightObjects = flightsRollup.map((d) => ({
    start: d[0],
    end: d[1],
    count: d[2]
  }));
  return d3.sort(flightObjects, (d) => [d.start, d.end]);
}


function _flightCountsFiltered(selectedTimeRange,selectedAirline,flights,d3,largeAirportCodes)
{
  const [rangeStart, rangeEnd] = selectedTimeRange;
  const airlineFiltered = selectedAirline === null ? flights : flights.filter(d => d.owner === selectedAirline);

  const timeFiltered = airlineFiltered.filter(d => {
    const flightStart = new Date(d.departure_dt);
    const flightEnd = new Date(d.arrival_dt);

    return flightStart < rangeEnd && flightEnd > rangeStart;
  });
  
  const flightsRollup = d3.flatRollup(
    timeFiltered.filter(
      d => largeAirportCodes.has(d.origin_apt) && largeAirportCodes.has(d.dest_apt)
    ),
    v => v.length,
    d => d.origin_apt,
    d => d.dest_apt
  );

  const flightObjects = flightsRollup.map(d => ({
    start: d[0],
    end: d[1],
    count: d[2]
  }));

  return d3.sort(flightObjects, d => [d.start, d.end]);
}


function _adjMatrix(Plot,largeAirportCodesSorted,flightCounts,d3)
{
    let adjMatrix = Plot.plot({
    height: 800,
    width: 800,
    padding: 0.05,
    x: {
      axis: "top",
      tickRotate: -90,
      domain: largeAirportCodesSorted
    },
    y: {
      domain: largeAirportCodesSorted
    },
    color: {
      type: "sqrt",
      scheme: "blues",
      legend: true,
      label: "Flight count"
    },
    marks: [
      Plot.cell(flightCounts, {
        x: d => d.end,
        y: d => d.start,
        z: d => [d.start,d.end],
        fill: d => d.count,
        title: d => `${d.start} -> ${d.end}`,
        className: "edges"
      }),
    ],
    marginLeft: 40,
    marginTop: 40,
  })
  
  d3.select(adjMatrix)
      .selectAll(".edges rect")
      .on("pointerover", event => {
        d3.select(adjMatrix)
          .selectAll(".edges rect")
          .attr("stroke", null);
  
        d3.select(event.currentTarget)
          .attr("stroke", "red")
          .attr("stroke-width", 2);
    })
    .on("pointerout", () => {
      d3.select(adjMatrix)
        .selectAll(".edges rect")
        .attr("stroke", null)
        .attr("stroke-width", null);
  });
  
  return adjMatrix
}


function _map(Plot,airports,states,flightCountsFiltered,airportLookup,largeAirports,highlightedArrowData){return(
Plot.plot({
  projection: {
    type: "albers",
    domain: airports
  },
  inset: 20,
  marks: [
    Plot.geo(states, { fill: "white", title: "name", stroke: "gray" }),
    Plot.arrow(flightCountsFiltered, {
      x1: (d) => airportLookup.get(d.start).lon,
      y1: (d) => airportLookup.get(d.start).lat,
      x2: (d) => airportLookup.get(d.end).lon,
      y2: (d) => airportLookup.get(d.end).lat,
      z: (d) => [d.start,d.end],
      bend: true,
      insetEnd: 6,
      insetStart: 3,
      strokeWidth: (d) => 1.5 * Math.log10(d.count),
      title: (d) => `${d.start} -> ${d.end}`,
      className: "arrows"
    }),
    Plot.dot(largeAirports, {
      x: "lon",
      y: "lat",
      r: 3,
      sort: null,
      fill: "black",
      className: "airports"
    }),

    Plot.arrow(highlightedArrowData, {
      x1: d => airportLookup.get(d.start).lon,
      y1: d => airportLookup.get(d.start).lat,
      x2: d => airportLookup.get(d.end).lon,
      y2: d => airportLookup.get(d.end).lat,
      z:  d => [d.start, d.end],
      bend: true,
      insetEnd: 6,
      insetStart: 3,
      stroke: "red",
      strokeWidth: 4,
      title: d => `${d.start} -> ${d.end}`,
      classname: "highlighted-arrow"
    })
  ],
  //height: 800
  width: 1000
})
)}

function _17(md){return(
md`### Parts 1 & 2 (Multiple View & Filtering)
Create the multiple view visualization with both the map and matrix defined above. Add color to the matrix and add the two filters.`
)}

function _combined(html,map,adjMatrix)
{
  return html`<div class="jux">
    ${map}
    ${adjMatrix}
  </div>`
}


function _19(htl){return(
htl.html`<style>
  .jux {
    display: flex;
  }
</style>`
)}

function _selectedAirline(Inputs){return(
Inputs.select(
  [
    null, 
    "SOUTHWEST AIRLINES CO",
    "DELTA AIR LINES INC",
    "AMERICAN AIRLINES INC",
    "UNITED AIRLINES INC"
  ],
  {
    label: "Airline",
    format: d => d === null ? "All airlines" : d,
    value: null
  }
)
)}

function _selectedTimeRange(timeRange){return(
timeRange(
  new Date(2026,2,1,0,0,0),
  new Date(2026,2,2,0,0,0),
  {
    interval: "minute",
    value: [
      new Date(2026,2,1,0,0,0),
      new Date(2026,2,2,0,0,0)
    ]
  }
)
)}

function _22(htl){return(
htl.html`<style>
  .highlighted {
    stroke: red;
    stroke-width: 2.5px;
  }

  .highlighted.airport-dot {
    fill: red;
    stroke: black;
    stroke-width: 1.5px;
  }
</style>`
)}

function _23(md){return(
md`### Part 3 (Linked Highlighting)`
)}

function _highlightedArrowData(hoveredRoute){return(
hoveredRoute ? [hoveredRoute] : []
)}

function _hoveredRoute(){return(
null
)}

function _dataJoin(combined,d3,adjMatrix,flightCountsFiltered,map,largeAirports,largeAirportCodesSorted)
{
   combined;

  const cells = d3.select(adjMatrix).selectAll(".edges rect").data(flightCountsFiltered);
  const lines = d3.select(map).selectAll(".arrows path").data(largeAirports);
  const points = d3.select(map).selectAll(".airports circle").data(largeAirports);
  const xLabels = d3.select(adjMatrix).selectAll('g[aria-label="x-axis tick label"] text').data(largeAirportCodesSorted);
  const yLabels = d3.select(adjMatrix).selectAll('g[aria-label="y-axis tick label"] text').data(largeAirportCodesSorted);

  return null;
}


function _27(dataJoin,d3,adjMatrix,map,$0)
{
  dataJoin;

  const cellSelection = 
    d3.select(adjMatrix)
      .selectAll(".edges rect")    

  const arrowSelection = 
    d3.select(map)
      .selectAll(".arrows path")

  const airportSelection =
    d3.select(map)
      .selectAll(".airports circle")

  function clearHighlights() {
    cellSelection.classed("highlighted", false);
    arrowSelection.classed("highlighted", false);
    airportSelection.classed("highlighted", false).classed("airport-dot", false);

    $0.value = null;
  }

  cellSelection.on("pointerover", (event, d) => {    
    cellSelection.classed("highlighted", c => c.start === d.start && c.end === d.end);
    
    airportSelection.classed("highlighted", p => p.loc_id === d.start || p.loc_id === d.end)
                    .classed("airport-dot", p => p.loc_id === d.start || p.loc_id === d.end);

    $0.value = d;
  }).on("pointerout", () => {
    clearHighlights();
  })

}


function _28(md){return(
md`### Part 4 (Hexbin)`
)}

async function _client(DuckDBClient)
{
  const client = await DuckDBClient.of();
  await client.sql`
    CREATE VIEW flight_paths AS SELECT * FROM read_parquet("https://raw.githubusercontent.com/dakoop/niu-cs627-2026sp/refs/heads/main/a5/us-flights-thin-2026-03-01.parquet");
  `;
  return client;
}


function _flightPaths(client){return(
client.sql`SELECT * from flight_paths;`
)}

function _flightPathHexbin(Plot,states,flightPaths){return(
Plot.plot({
  width: 1000,
  projection: {
    type: "albers"
  },
  color: {
    type: "log",
    domain: [1,10000],
    scheme: "plasma",
    legend: true,
    ticks: [10,100,1000,10000],
    label: "Flight density"
  },
  marks: [
    Plot.geo(states, {
      fill: "none",
      stroke: "gray",
      strokeOpacity: 0.7,
      strokeWidth: 0.6
    }),

    Plot.dot(
      flightPaths,
      Plot.hexbin(
        {fill: "count"},
        {
          x: "lon",
          y: "lat",
          binWidth: 10,
          r: 6,
          fillOpacity: 0.9,
          tip: true
        }
      )
    ),

    Plot.geo(states, {
      fill: "none",
      stroke: "white",
      strokeOpacity: 0.5,
      strokeWidth: 0.7
    })
  ]
})
)}

export default function define(runtime, observer) {
  const main = runtime.module();
  main.variable(observer()).define(["htl"], _1);
  main.variable(observer()).define(["htl"], _2);
  const child1 = runtime.module(define1);
  main.import("timeRange", child1);
  main.variable(observer("states")).define("states", ["d3"], _states);
  main.variable(observer("flights")).define("flights", ["d3"], _flights);
  main.variable(observer("airports")).define("airports", ["d3"], _airports);
  main.variable(observer("airportLookup")).define("airportLookup", ["airports"], _airportLookup);
  main.variable(observer("airportCounts")).define("airportCounts", ["d3","flights"], _airportCounts);
  main.variable(observer("LARGE_THRESHOLD")).define("LARGE_THRESHOLD", _LARGE_THRESHOLD);
  main.variable(observer("largeAirportCodes")).define("largeAirportCodes", ["airportCounts","LARGE_THRESHOLD"], _largeAirportCodes);
  main.variable(observer("largeAirportCodesSorted")).define("largeAirportCodesSorted", ["largeAirportCodes"], _largeAirportCodesSorted);
  main.variable(observer("largeAirports")).define("largeAirports", ["airports","largeAirportCodes"], _largeAirports);
  main.variable(observer("flightCounts")).define("flightCounts", ["d3","flights","largeAirportCodes"], _flightCounts);
  main.variable(observer("flightCountsFiltered")).define("flightCountsFiltered", ["selectedTimeRange","selectedAirline","flights","d3","largeAirportCodes"], _flightCountsFiltered);
  main.variable(observer("adjMatrix")).define("adjMatrix", ["Plot","largeAirportCodesSorted","flightCounts","d3"], _adjMatrix);
  main.variable(observer("map")).define("map", ["Plot","airports","states","flightCountsFiltered","airportLookup","largeAirports","highlightedArrowData"], _map);
  main.variable(observer()).define(["md"], _17);
  main.variable(observer("combined")).define("combined", ["html","map","adjMatrix"], _combined);
  main.variable(observer()).define(["htl"], _19);
  main.variable(observer("viewof selectedAirline")).define("viewof selectedAirline", ["Inputs"], _selectedAirline);
  main.variable(observer("selectedAirline")).define("selectedAirline", ["Generators", "viewof selectedAirline"], (G, _) => G.input(_));
  main.variable(observer("viewof selectedTimeRange")).define("viewof selectedTimeRange", ["timeRange"], _selectedTimeRange);
  main.variable(observer("selectedTimeRange")).define("selectedTimeRange", ["Generators", "viewof selectedTimeRange"], (G, _) => G.input(_));
  main.variable(observer()).define(["htl"], _22);
  main.variable(observer()).define(["md"], _23);
  main.variable(observer("highlightedArrowData")).define("highlightedArrowData", ["hoveredRoute"], _highlightedArrowData);
  main.define("initial hoveredRoute", _hoveredRoute);
  main.variable(observer("mutable hoveredRoute")).define("mutable hoveredRoute", ["Mutable", "initial hoveredRoute"], (M, _) => new M(_));
  main.variable(observer("hoveredRoute")).define("hoveredRoute", ["mutable hoveredRoute"], _ => _.generator);
  main.variable(observer("dataJoin")).define("dataJoin", ["combined","d3","adjMatrix","flightCountsFiltered","map","largeAirports","largeAirportCodesSorted"], _dataJoin);
  main.variable(observer()).define(["dataJoin","d3","adjMatrix","map","mutable hoveredRoute"], _27);
  main.variable(observer()).define(["md"], _28);
  main.variable(observer("client")).define("client", ["DuckDBClient"], _client);
  main.variable(observer("flightPaths")).define("flightPaths", ["client"], _flightPaths);
  main.variable(observer("flightPathHexbin")).define("flightPathHexbin", ["Plot","states","flightPaths"], _flightPathHexbin);
  return main;
}
