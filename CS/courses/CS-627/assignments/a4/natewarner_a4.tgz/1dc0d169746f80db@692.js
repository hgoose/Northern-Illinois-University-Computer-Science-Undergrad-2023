function _1(md){return(
md`<div id="info">
  <div class="left">
    <h1 class="left-text">Nate Warner</h1>
    <h2 class="left-text">z2004109</h2>
  </div>
  <div class="right">
    <h2 class="right-text">Data visualization (CSCI 627/490 Section N9)</h2>
    <h2 class="right-text">Assignment 4</h2>
  </div>
</div>`
)}

function _2(htl){return(
htl.html`<style>
  * { margin: 0; }

  #info { display: flex }

  .left {
    margin: 1%;
    display: flex;
    width: 70%;
    flex-direction: column;
  }
  .left .left-text { color: blue; }

  .right {
    margin: 1%;
    display: flex;
    flex-direction: column;
    width: 30%;
    border: 3px solid green;
  }
  .right .right-text {
    text-align: right;
    margin-right: 10px;
    color: blue;
    font-style: italic;
    font-weight: normal;
  }
</style>`
)}

function _mapData(d3){return(
d3.json("https://gist.githubusercontent.com/dakoop/771a0c3ca9c75c7c7fdc33b12b578724/raw/025cbd5dd1a263659bfb62594d0fe0463e008283/us-states.geosjson")
)}

function _region_data(d3){return(
d3.csv("https://gist.githubusercontent.com/dakoop/771a0c3ca9c75c7c7fdc33b12b578724/raw/025cbd5dd1a263659bfb62594d0fe0463e008283/us-regions.csv")
)}

function _electricity_data(d3){return(
d3.json("https://gist.githubusercontent.com/dakoop/771a0c3ca9c75c7c7fdc33b12b578724/raw/025cbd5dd1a263659bfb62594d0fe0463e008283/us-electricity.json")
)}

function _w(){return(
800
)}

function _h(){return(
600
)}

function _usa_projection(d3,w,h,mapData){return(
d3.geoAlbersUsa().fitSize([w,h], mapData)
)}

function _discrete_colormap_legend(d3,w){return(
function discrete_colormap_legend(svg, colormap, height, markings) {
  let xscale = d3.scaleBand().domain(colormap).range([0,w]);
  let mark_scale = d3.scaleBand().domain(colormap).range([0,w]);
  let width =   w / colormap.length;
  
  colormap.forEach((color,i) => {
    svg.append("rect")
      .attr("x", xscale(color))
      .attr("y",0)
      .attr("width", width)
      .attr("height", height)
      .attr("fill", color)

    svg.append("text")
      .attr("x", mark_scale(color))
      .attr("y",height*2)
      .text(markings[i])
      .attr("font-size", ".6rem");
    
  })
}
)}

function _cont_colormap_legend(d3,w){return(
function cont_colormap_legend(svg, colormap, height, lmr_marks, right_mark_push) {
  let xscale = d3.scaleBand().domain(colormap).range([0,w]);
  let width =   w / colormap.length;

  let leftIndex = 0;
  let middleIndex = Math.floor((colormap.length - 1) / 2);
  let rightIndex = colormap.length - 1;

  colormap.forEach((color,i) => {
    svg.append("rect")
      .attr("x", xscale(color))
      .attr("y",0)
      .attr("width", width)
      .attr("height", height)
      .attr("fill", color)

    if (i === leftIndex) {
      svg.append("text")
        .attr("x", 0)
        .attr("y", height * 2)
        .text(lmr_marks[0]);
    }

    if (i === middleIndex) {
      svg.append("text")
        .attr("x", w / 2)
        .attr("y", height * 2)
        .attr("text-anchor", "middle")
        .text(lmr_marks[1]);
    }

    if (i === rightIndex) {
      svg.append("text")
        .attr("x", w - right_mark_push)
        .attr("y", height * 2)
        .text(lmr_marks[2]);
    }
  });
}
)}

function _usa_map(d3,w,h,mapData,usa_projection){return(
function usa_map(fill) {
   let svg = d3.create("svg")
              .attr("width", w)
              .attr("height", h);
  
  let states = mapData.features;
  
  let path = d3.geoPath().projection(usa_projection);
  states.forEach(d => {
    
    svg.append("path")
      .datum(d)
      .attr("d", path)
      .attr("stroke", "black")
      .attr("fill", "#9C9C9C")
  });

  return svg.node();
}
)}

function _12(usa_map){return(
usa_map("#9C9C9C")
)}

function _regions(region_data){return(
Array.from(new Set(region_data.map(d => d.Division)))
)}

function _region_colormap(){return(
["#a6cee3","#1f78b4","#b2df8a","#33a02c","#fb9a99","#e31a1c","#fdbf6f","#ff7f00","#cab2d6"]
)}

function _state_divisions(region_data)
{
  let state_divisions = {}
  region_data.forEach(d => {
    state_divisions[d.State] = d.Division;
  })
  return state_divisions;
}


function _16(htl){return(
htl.html`<div><h1>Census division</h1></div>`
)}

function _17(d3,w,h,mapData,usa_projection,region_colormap,regions,state_divisions,discrete_colormap_legend)
{ 
  let svg = d3.create("svg")
              .attr("width", w)
              .attr("height", h);
  
  let states = mapData.features;
  
  let path = d3.geoPath().projection(usa_projection);
  states.forEach(d => {
    svg.append("path")
      .datum(d)
      .attr("d", path)
      .attr("stroke", "black")
      .attr("fill", region_colormap[regions.indexOf(state_divisions[d.properties.name])]);
  });
  discrete_colormap_legend(svg, region_colormap, 20, regions);

  return svg.node();
}


function _18(htl){return(
htl.html`<div><h2>Question:</h2></italic>If we are interested in understanding how much a state leverages nuclear energy, what is a problem with this visualization?</div>
<div><h2>Answer:</h2>A state on the high end of the colormap could just mean that they generate alot of power, it tells us nothing about the leverage of nuclear energy in comparison to the total energy they produce. A better vis for understanding leverage would be percentage based (percentage of nuclear energy)</div>`
)}

function _nu2023(electricity_data){return(
electricity_data.filter(d => {
  return d.Year == 2023 && d.FuelCode == "NU";
})
)}

function _nu2023_state_to_data(nu2023)
{
  let nu2023_state_to_data = {};
  nu2023.forEach(d => {
    nu2023_state_to_data[d.StateCode] = d.Data
  })
  return nu2023_state_to_data;
}


function _nu2023_colormap(){return(
["#fffffd", "#fff7ec","#fff7eb","#fff6ea","#fff6e9","#fff5e7","#fff5e6","#fff4e5","#fff4e4","#fff3e3","#fff3e2","#fff2e1","#fff2e0","#fff1de","#fff1dd","#fff0dc","#fff0db","#feefda","#feefd9","#feeed7","#feeed6","#feedd5","#feedd4","#feecd3","#feecd2","#feebd0","#feebcf","#feeace","#feeacd","#fee9cc","#fee9ca","#fee8c9","#fee8c8","#fee7c7","#fee7c6","#fee6c4","#fee5c3","#fee5c2","#fee4c1","#fee4bf","#fee3be","#fee3bd","#fee2bc","#fee1ba","#fee1b9","#fee0b8","#fee0b7","#fedfb5","#fedeb4","#fedeb3","#fdddb2","#fddcb1","#fddcaf","#fddbae","#fddaad","#fddaac","#fdd9ab","#fdd8a9","#fdd8a8","#fdd7a7","#fdd6a6","#fdd6a5","#fdd5a4","#fdd4a3","#fdd4a1","#fdd3a0","#fdd29f","#fdd29e","#fdd19d","#fdd09c","#fdcf9b","#fdcf9a","#fdce99","#fdcd98","#fdcc97","#fdcc96","#fdcb95","#fdca94","#fdc994","#fdc893","#fdc892","#fdc791","#fdc690","#fdc58f","#fdc48e","#fdc38d","#fdc28c","#fdc18b","#fdc08a","#fdbf89","#fdbe88","#fdbd87","#fdbc86","#fdbb85","#fdba84","#fdb983","#fdb882","#fdb781","#fdb680","#fdb57f","#fdb47d","#fdb27c","#fdb17b","#fdb07a","#fdaf79","#fdae78","#fdac76","#fdab75","#fdaa74","#fca873","#fca772","#fca671","#fca46f","#fca36e","#fca26d","#fca06c","#fc9f6b","#fc9e6a","#fc9c68","#fc9b67","#fb9a66","#fb9865","#fb9764","#fb9563","#fb9462","#fb9361","#fb9160","#fa905f","#fa8f5e","#fa8d5d","#fa8c5c","#f98b5b","#f9895a","#f98859","#f98759","#f88558","#f88457","#f88356","#f78155","#f78055","#f77f54","#f67d53","#f67c52","#f67b52","#f57951","#f57850","#f4774f","#f4754f","#f4744e","#f3734d","#f3714c","#f2704c","#f26f4b","#f16d4a","#f16c49","#f06b49","#f06948","#ef6847","#ef6646","#ee6545","#ed6344","#ed6243","#ec6042","#ec5f42","#eb5d41","#ea5c40","#ea5a3f","#e9593e","#e8573c","#e8563b","#e7543a","#e65339","#e65138","#e55037","#e44e36","#e44c35","#e34b34","#e24932","#e14831","#e04630","#e0442f","#df432e","#de412d","#dd402b","#dc3e2a","#dc3c29","#db3b28","#da3927","#d93826","#d83624","#d73423","#d63322","#d53121","#d43020","#d32e1f","#d22c1e","#d12b1d","#d0291b","#cf281a","#ce2619","#cd2518","#cc2317","#cb2216","#ca2015","#c91f14","#c81d13","#c71c12","#c61b11","#c51911","#c31810","#c2170f","#c1150e","#c0140d","#bf130c","#be120c","#bc110b","#bb100a","#ba0e09","#b80d09","#b70c08","#b60b07","#b50b07","#b30a06","#b20906","#b10805","#af0705","#ae0704","#ac0604","#ab0504","#a90503","#a80403","#a60402","#a50302","#a40302","#a20302","#a00201","#9f0201","#9d0201","#9c0101","#9a0101","#990101","#970101","#960100","#940100","#920000","#910000","#8f0000","#8e0000","#8c0000","#8a0000","#890000","#870000","#860000","#840000","#820000","#810000","#7f0000"]
)}

function _nu2023_colormap_value(d3,nu2023,nu2023_colormap){return(
d3.scaleLinear().domain(d3.extent(nu2023.map(d => d.Data))).range([0, nu2023_colormap.length-1])
)}

function _range(d3,nu2023){return(
d3.extent(nu2023.map(d => d.Data))
)}

function _24(htl){return(
htl.html`<div><h1>2023 Nuclear energy</h1></div>`
)}

function _25(d3,w,h,mapData,usa_projection,nu2023_colormap,nu2023_colormap_value,nu2023_state_to_data,cont_colormap_legend,range)
{ 
  let svg = d3.create("svg")
              .attr("width", w)
              .attr("height", h);
  
  let states = mapData.features;

  let path = d3.geoPath().projection(usa_projection);
  states.forEach(d => {
    svg.append("path")
      .datum(d)
      .attr("d", path)
      .attr("stroke", "black")
      .attr("fill", nu2023_colormap[Math.round(nu2023_colormap_value(nu2023_state_to_data[d.properties.postal]))])

    cont_colormap_legend(svg, nu2023_colormap, 20, [range[0], range[1]/2, range[1]], 75);
  });

  return svg.node();
}


function _total_2023_energy_by_state(electricity_data)
{
  let total_2023_energy = {}
  
  electricity_data.filter(d => d.Year == 2023).forEach(d => {
    total_2023_energy[d.StateCode] ??= 0;
    total_2023_energy[d.StateCode] += d.Data;
  });
  
  return total_2023_energy;
}


function _nu2023_percentage_colormap_value(d3,nu2023_colormap){return(
d3.scaleLinear()
    .domain([0,1])
    .range([0, nu2023_colormap.length-1])
)}

function _nu_percentage_2023(mapData,nu2023_state_to_data,total_2023_energy_by_state)
{
  let nu_percentage_2023 = {};

  mapData.features.forEach(d => {
    nu_percentage_2023[d.properties.postal] = nu2023_state_to_data[d.properties.postal] / total_2023_energy_by_state[d.properties.postal]
  })

  return nu_percentage_2023;
}


function _29(htl){return(
htl.html`<div><h1>2023 Nuclear Energy Percentage</h1></div>`
)}

function _30(d3,w,h,mapData,usa_projection,nu2023_colormap,nu2023_percentage_colormap_value,nu_percentage_2023,cont_colormap_legend)
{ 
  let svg = d3.create("svg")
              .attr("width", w)
              .attr("height", h);
  
  let states = mapData.features;

  let path = d3.geoPath().projection(usa_projection)
  states.forEach(d => {
    svg.append("path")
      .datum(d)
      .attr("d", path)
      .attr("stroke", "black")
      .attr("fill", nu2023_colormap[Math.round(nu2023_percentage_colormap_value(nu_percentage_2023[d.properties.postal]))])
  });

  cont_colormap_legend(svg, nu2023_colormap, 20, ["0%", "50%", "100%"], 40);

  return svg.node();
}


function _total_2000_energy_by_state(electricity_data)
{
  let total_2000_energy = {}
  
  electricity_data.filter(d => d.Year == 2000).forEach(d => {
    total_2000_energy[d.StateCode] ??= 0;
    total_2000_energy[d.StateCode] += d.Data;
  });
  
  return total_2000_energy;
}


function _nu2000_state_to_data(electricity_data)
{
  let nu2000_state_to_data = {};
  electricity_data.filter(d => d.Year == 2000 && d.FuelCode == "NU").forEach(d => {
    nu2000_state_to_data[d.StateCode] = d.Data
  })
  return nu2000_state_to_data;
}


function _nu_percentage_2000(mapData,nu2000_state_to_data,total_2000_energy_by_state)
{
  let nu_percentage_2000 = {};

  mapData.features.forEach(d => {
    nu_percentage_2000[d.properties.postal] = nu2000_state_to_data[d.properties.postal] / total_2000_energy_by_state[d.properties.postal]
  })

  return nu_percentage_2000;
}


function _percentage_change_colormap(){return(
["#8e0152","#900254","#920355","#940457","#970559","#99065a","#9b075c","#9d085e","#9f0960","#a10b61","#a30c63","#a50d65","#a70e66","#a91068","#ab116a","#ad136b","#af146d","#b1166f","#b31771","#b51972","#b71b74","#b91d76","#ba1e78","#bc217a","#be237b","#bf257d","#c1277f","#c22a81","#c42c83","#c52f84","#c73186","#c83488","#c9378a","#cb3a8c","#cc3d8e","#cd408f","#ce4391","#cf4693","#d04995","#d24c97","#d34f99","#d4529b","#d5569d","#d6599e","#d75ca0","#d85fa2","#d963a4","#d966a6","#da69a8","#db6caa","#dc6fab","#dd72ad","#de75af","#df78b1","#e07bb3","#e07eb4","#e181b6","#e284b8","#e386ba","#e489bb","#e48cbd","#e58ebf","#e691c1","#e794c2","#e796c4","#e899c5","#e99bc7","#ea9dc9","#eaa0ca","#eba2cc","#eca4cd","#eca7cf","#eda9d0","#eeabd1","#eeadd3","#efafd4","#f0b1d6","#f0b4d7","#f1b6d8","#f1b8d9","#f2bada","#f2bbdc","#f3bddd","#f4bfde","#f4c1df","#f5c3e0","#f5c5e1","#f5c6e2","#f6c8e3","#f6cae4","#f7cbe4","#f7cde5","#f8cfe6","#f8d0e7","#f8d2e8","#f9d3e8","#f9d5e9","#f9d6ea","#f9d8ea","#fad9eb","#fadaec","#fadcec","#fadded","#fadeed","#fadfee","#fae1ee","#fae2ef","#fae3ef","#fae4f0","#fae5f0","#fae6f1","#fae7f1","#fae8f1","#fae9f1","#faeaf2","#f9ebf2","#f9ecf2","#f9ecf2","#f9edf2","#f8eef2","#f8eff2","#f8eff2","#f7f0f1","#f7f1f1","#f7f1f1","#f6f2f0","#f6f2f0","#f5f3ef","#f5f3ef","#f4f3ee","#f4f4ed","#f3f4ed","#f3f4ec","#f2f5eb","#f2f5ea","#f1f5e9","#f1f5e7","#f0f5e6","#eff5e5","#eff5e4","#eef5e2","#edf5e1","#ecf5df","#ebf5de","#ebf5dc","#eaf5da","#e9f4d8","#e8f4d6","#e7f4d5","#e6f3d3","#e5f3d1","#e4f3ce","#e2f2cc","#e1f2ca","#e0f2c8","#dff1c6","#ddf1c3","#dcf0c1","#daefbe","#d9efbc","#d7eeb9","#d6eeb7","#d4edb4","#d3ecb2","#d1ecaf","#cfebac","#ceeaaa","#cce9a7","#cae8a4","#c8e8a1","#c7e79f","#c5e69c","#c3e599","#c1e496","#bfe393","#bde291","#bbe18e","#b9e08b","#b7df88","#b5de85","#b3dc83","#b1db80","#afda7d","#add97a","#abd878","#a9d675","#a7d572","#a5d46f","#a2d26d","#a0d16a","#9ed068","#9cce65","#9acd62","#98cc60","#96ca5d","#93c95b","#91c759","#8fc656","#8dc454","#8bc352","#89c150","#87c04d","#84be4b","#82bd49","#80bb47","#7eba45","#7cb843","#7ab641","#78b540","#76b33e","#74b23c","#72b03b","#70af39","#6ead38","#6cab36","#6aaa35","#68a833","#66a632","#64a531","#62a32f","#60a12e","#5ea02d","#5c9e2c","#5b9c2b","#599b2a","#579929","#559728","#539627","#529426","#509225","#4e9025","#4c8f24","#4b8d23","#498b22","#478a22","#468821","#448621","#438420","#418220","#3f811f","#3e7f1f","#3c7d1e","#3b7b1e","#397a1d","#38781d","#36761c","#34741c","#33721c","#31711b","#306f1b","#2e6d1b","#2d6b1a","#2b691a","#2a681a","#286619","#276419"]
)}

function _percentage_change_colormap_value(d3,percentage_change_colormap){return(
d3.scaleLinear().domain([-1,1]).range([0, percentage_change_colormap.length-1])
)}

function _nu_percentage_change(nu_percentage_2000,nu_percentage_2023)
{
  let nu_percentage_change = {};

  Object.keys(nu_percentage_2000).forEach(d => {
    nu_percentage_change[d] = nu_percentage_2023[d] - nu_percentage_2000[d];
  });
  
  return nu_percentage_change;
}


function _37(htl){return(
htl.html`<div><h1>Nuclear energy percent change 2023-2000</h1></div>`
)}

function _38(d3,w,h,mapData,usa_projection,percentage_change_colormap,percentage_change_colormap_value,nu_percentage_change,cont_colormap_legend)
{ 
  let svg = d3.create("svg")
              .attr("width", w)
              .attr("height", h);
  
  let states = mapData.features;
  let path = d3.geoPath().projection(usa_projection);
  states.forEach(d => {
    svg.append("path")
      .datum(d)
      .attr("d", path)
      .attr("stroke", "black")
      .attr("fill", percentage_change_colormap[Math.round(percentage_change_colormap_value(nu_percentage_change[d.properties.postal]))])
  });
  cont_colormap_legend(svg, percentage_change_colormap, 20, ["-100%", "0%", "100%"], 50)

  return svg.node();
}


export default function define(runtime, observer) {
  const main = runtime.module();
  main.variable(observer()).define(["md"], _1);
  main.variable(observer()).define(["htl"], _2);
  main.variable(observer("mapData")).define("mapData", ["d3"], _mapData);
  main.variable(observer("region_data")).define("region_data", ["d3"], _region_data);
  main.variable(observer("electricity_data")).define("electricity_data", ["d3"], _electricity_data);
  main.variable(observer("w")).define("w", _w);
  main.variable(observer("h")).define("h", _h);
  main.variable(observer("usa_projection")).define("usa_projection", ["d3","w","h","mapData"], _usa_projection);
  main.variable(observer("discrete_colormap_legend")).define("discrete_colormap_legend", ["d3","w"], _discrete_colormap_legend);
  main.variable(observer("cont_colormap_legend")).define("cont_colormap_legend", ["d3","w"], _cont_colormap_legend);
  main.variable(observer("usa_map")).define("usa_map", ["d3","w","h","mapData","usa_projection"], _usa_map);
  main.variable(observer()).define(["usa_map"], _12);
  main.variable(observer("regions")).define("regions", ["region_data"], _regions);
  main.variable(observer("region_colormap")).define("region_colormap", _region_colormap);
  main.variable(observer("state_divisions")).define("state_divisions", ["region_data"], _state_divisions);
  main.variable(observer()).define(["htl"], _16);
  main.variable(observer()).define(["d3","w","h","mapData","usa_projection","region_colormap","regions","state_divisions","discrete_colormap_legend"], _17);
  main.variable(observer()).define(["htl"], _18);
  main.variable(observer("nu2023")).define("nu2023", ["electricity_data"], _nu2023);
  main.variable(observer("nu2023_state_to_data")).define("nu2023_state_to_data", ["nu2023"], _nu2023_state_to_data);
  main.variable(observer("nu2023_colormap")).define("nu2023_colormap", _nu2023_colormap);
  main.variable(observer("nu2023_colormap_value")).define("nu2023_colormap_value", ["d3","nu2023","nu2023_colormap"], _nu2023_colormap_value);
  main.variable(observer("range")).define("range", ["d3","nu2023"], _range);
  main.variable(observer()).define(["htl"], _24);
  main.variable(observer()).define(["d3","w","h","mapData","usa_projection","nu2023_colormap","nu2023_colormap_value","nu2023_state_to_data","cont_colormap_legend","range"], _25);
  main.variable(observer("total_2023_energy_by_state")).define("total_2023_energy_by_state", ["electricity_data"], _total_2023_energy_by_state);
  main.variable(observer("nu2023_percentage_colormap_value")).define("nu2023_percentage_colormap_value", ["d3","nu2023_colormap"], _nu2023_percentage_colormap_value);
  main.variable(observer("nu_percentage_2023")).define("nu_percentage_2023", ["mapData","nu2023_state_to_data","total_2023_energy_by_state"], _nu_percentage_2023);
  main.variable(observer()).define(["htl"], _29);
  main.variable(observer()).define(["d3","w","h","mapData","usa_projection","nu2023_colormap","nu2023_percentage_colormap_value","nu_percentage_2023","cont_colormap_legend"], _30);
  main.variable(observer("total_2000_energy_by_state")).define("total_2000_energy_by_state", ["electricity_data"], _total_2000_energy_by_state);
  main.variable(observer("nu2000_state_to_data")).define("nu2000_state_to_data", ["electricity_data"], _nu2000_state_to_data);
  main.variable(observer("nu_percentage_2000")).define("nu_percentage_2000", ["mapData","nu2000_state_to_data","total_2000_energy_by_state"], _nu_percentage_2000);
  main.variable(observer("percentage_change_colormap")).define("percentage_change_colormap", _percentage_change_colormap);
  main.variable(observer("percentage_change_colormap_value")).define("percentage_change_colormap_value", ["d3","percentage_change_colormap"], _percentage_change_colormap_value);
  main.variable(observer("nu_percentage_change")).define("nu_percentage_change", ["nu_percentage_2000","nu_percentage_2023"], _nu_percentage_change);
  main.variable(observer()).define(["htl"], _37);
  main.variable(observer()).define(["d3","w","h","mapData","usa_projection","percentage_change_colormap","percentage_change_colormap_value","nu_percentage_change","cont_colormap_legend"], _38);
  return main;
}
