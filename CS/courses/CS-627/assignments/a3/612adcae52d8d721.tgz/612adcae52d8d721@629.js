function _1(md){return(
md`<div id="info">
  <div class="left">
    <h1 class="left-text">Nate Warner</h1>
    <h2 class="left-text">z2004109</h2>
  </div>
  <div class="right">
    <h2 class="right-text">Data visualization (CSCI 627/490 Section N9)</h2>
    <h2 class="right-text">Assignment 3</h2>
  </div>
</div>`
)}

function _2(htl){return(
htl.html`<style>
  * { margin: 0; }

  #info { display: flex }

  .left {
    margin: 1%;
    display: flex;
    width: 70%;
    flex-direction: column;
  }
  .left .left-text { color: blue; }

  .right {
    margin: 1%;
    display: flex;
    flex-direction: column;
    width: 30%;
    border: 3px solid green;
  }
  .right .right-text {
    text-align: right;
    margin-right: 10px;
    color: blue;
    font-style: italic;
    font-weight: normal;
  }
</style>`
)}

function _csv(d3){return(
d3.csv("https://raw.githubusercontent.com/dakoop/niu-cs627-2026sp/refs/heads/main/a3/chicago-traffic-crashes-24-25.csv", d3.autoType)
)}

function _intermediate(csv)
{
const intermediate = csv;
  
  intermediate.forEach(d => {
    const date = new Date(d.CRASH_DATE);
    d.CRASH_DATE = new Date(date.getFullYear(), date.getMonth(), 1);
  })
  return intermediate;
}


function _crashesByMonth(d3,intermediate)
{
  const crashesMonthType = d3.rollup(intermediate, v => v.length, d => (d.CRASH_DATE.getFullYear() + '-' + (d.CRASH_DATE.getMonth() + 1).toString().padStart(2,0)), d => d.FIRST_CRASH_TYPE);
  
const crashesByMonth = [...crashesMonthType.entries()].map(d => ({...Object.fromEntries([...d[1].entries()]), "Total": d3.sum(d[1].values()), "Date": d[0]}))

  return crashesByMonth;
}


function _data(crashesByMonth)
{
  const keys = Object.keys(crashesByMonth[0]).slice(0,Object.keys(crashesByMonth[0]).length-2);
  
  const other = keys.flatMap(d => {
    return crashesByMonth.map(v => {
      return {"Date": v.Date, "Crash type": d, "Total": v[d]};
    })
  })
  
  return other;
}


function _7(htl){return(
htl.html`<img src="https://i.imgur.com/a7KR8Mb.png"> </img>
<a href="https://public.tableau.com/app/profile/nate.warner5705/viz/CrashtypesSBC/Sheet1"> Tableau Link</a>`
)}

function _8(Plot,d3,data)
{
const plot = Plot.plot({
  width: 1000,
  height: 600,
  margin: 50,
  marginBottom: 100,
  x: {tickFormat: p=>{const formatTime = d3.utcFormat("%Y %B"); return formatTime(new Date(p))}, tickPadding: 80, tickSize: 10, tickRotate: 270},
  y: {},
  color: {legend: "swatches", width: 1100, label: "Age (years)"},
  marks: [
    Plot.barY(
      data,
      {x: "Date", y: "Total", fill: "Crash type"}
    )
  ]
});

  return plot
}


function _d3_data(crashesByMonth,d3)
{
  const d3_data = crashesByMonth.map(d => {
    const date = new Date(d.Date)
    return {"Date": new Date(date.getFullYear(), date.getMonth()+1), "Total": d.Total}
  }) 
  return d3.sort(d3_data, (a,b) => new Date(a.Date) - new Date(b.Date))
}


function _10(d3,d3_data)
{  
  let svg = d3.create("svg");
  let group = svg.append("g");

  let margin = {left: 50, right: 25, bottom: 100, top: 25}
  let bar_pad = 5;

  let W = 600, H = 400;
  svg.attr("width", W+margin.left+margin.right).attr("height", H+margin.top+margin.bottom);
  
  group.attr("transform", `translate(${margin.left}, ${margin.top})`);
  
  let xScale = d3.scaleBand().domain(d3_data.map(d => {return new Date(d.Date);})).range([0,W]);
  let yScale = d3.scaleLinear().domain([0, d3.max(d3_data.map(d => {return d.Total}))]).range([H,0]);

  group.selectAll("rect")
    .data(d3_data)
    .join("rect")
    .attr("x", d => xScale(d.Date))
    .attr("y", d => yScale(d.Total))
    .attr("width", xScale.bandwidth()-bar_pad)
    .attr("height", d => H-yScale(d.Total))
    .attr("fill", "#ff8ab7");

  let xAxis = d3.axisBottom(xScale).tickFormat(d3.timeFormat("%Y %B"));
  
  svg.append("g")
    .attr("transform", `translate(${margin.left},${H+margin.top})`)
    .call(xAxis)
    .selectAll("text")
    .attr("transform", `rotate(90)`)
    .attr("dx", "1rem")
    .attr("dy", "-0.5rem")
    .attr("style", "text-anchor: start;");
  

  let yAxis = d3.axisLeft(yScale);
  svg.append("g")
    .attr("transform", `translate(${margin.left}, ${margin.top})`)
    .call(yAxis);

  return svg.node();
}


export default function define(runtime, observer) {
  const main = runtime.module();
  main.variable(observer()).define(["md"], _1);
  main.variable(observer()).define(["htl"], _2);
  main.variable(observer("csv")).define("csv", ["d3"], _csv);
  main.variable(observer("intermediate")).define("intermediate", ["csv"], _intermediate);
  main.variable(observer("crashesByMonth")).define("crashesByMonth", ["d3","intermediate"], _crashesByMonth);
  main.variable(observer("data")).define("data", ["crashesByMonth"], _data);
  main.variable(observer()).define(["htl"], _7);
  main.variable(observer()).define(["Plot","d3","data"], _8);
  main.variable(observer("d3_data")).define("d3_data", ["crashesByMonth","d3"], _d3_data);
  main.variable(observer()).define(["d3","d3_data"], _10);
  return main;
}
